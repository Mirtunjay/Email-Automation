
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

@RunWith(Parameterized.class)
public class DemoEmail {
//
	public static WebDriver driver;
	public static String launchURL = "https://login.live.com/";

	public static void browserSetUp() {
		String path = System.getProperty("user.dir");
		String driverpath = path + "\\Driver\\chromedriver.exe";
		System.out.println(path);
		System.out.println(driverpath);
		System.setProperty("webdriver.chrome.driver", driverpath);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(launchURL);

	}

	public static String getText(WebDriver driver, String identifier) {

		return driver.findElement(By.xpath(identifier)).getText();
	}

	public void assertEqual(WebDriver driver, String identifier, String expected) {

		String finded = driver.findElement(By.xpath(identifier)).getText();
		Assert.assertEquals(finded, expected);

	}

	public boolean tableDataValidationd(WebDriver driver, String locator, String predefinedString) {
		List<WebElement> tableEmailBody = driver.findElements(By.xpath(locator));
		for (WebElement rows : tableEmailBody) {
			if (rows.getText().contains(predefinedString)) {
				return true;
			}
		}
		return false;
	}

	public static void tearDown() {
		driver.quit();
	}

//	
	private String userName;
	private String passWord;
	public static String editBoxEmail = "//*[@id='i0116']";
	public static String editBoxPassword = "i0118";
	public static String btnNext = "idSIButton9";
	public static String btnSignIn = "//*[@id='lightbox']/div[3]/div/div[2]/div/div[4]/div[2]/div/div/div/div";
	public static String btnNo = "//*[@id='idBtn_Back']";
	public static String linkOutlook = "//*[@id='main-content-landing-react']//div/div/div[2]/a[2]";
	public static String inboxCount = "//*[@id='app']//div[2]/div[1]/div/span[3]/span/span[1]";
	public static String newEmailRow = "//*[@class='_3qXS6Uo8WFxax_lDWr_1a_']//div[@role='option']";
	public static String emailHeader = "//*[@id='immersiveExitButton']/following-sibling::div";
	public static String emailBody = "//*[@id='ReadingPaneContainerId']//div//table[2]//tr";

	public static String predefinedString = "XOXO word";

	public DemoEmail(String userName, String passWord) {
		this.userName = userName;
		this.passWord = passWord;
	}

	@Parameterized.Parameters
	public static Collection credentials() {
		return Arrays.asList(new Object[][] { { "validemailid", "password" },
				{ "validemailid@gmail.com", "password" }, { "password.com", "password" },
				{ "password@hotmail.com", "password@88920" }, });
	}

	@Parameters
	@Test
	public void junitTest() throws InterruptedException {
		browserSetUp();
		driver.findElement(By.xpath(editBoxEmail)).sendKeys(userName);
		driver.findElement(By.id(btnNext)).click();

		driver.findElement(By.id(editBoxPassword)).sendKeys(passWord);
		driver.findElement(By.xpath(btnSignIn)).click();

		driver.findElement(By.xpath(btnNo)).click();

		driver.findElement(By.xpath(linkOutlook)).click();
		String parent = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> I1 = s.iterator();

		while (I1.hasNext()) {
			String child_window = I1.next();
			if (!parent.equals(child_window)) {
				driver.switchTo().window(child_window);
				int newEmail = driver.findElements(By.xpath(inboxCount)).size();
				if (newEmail == 0) {
					System.out.println("Inbox has NO new Unread Email");

				} else {
					System.out.println("Inbox has new Unread Email");
					driver.findElement(By.xpath(newEmailRow)).click();
					String emailHeaderText = getText(driver, emailHeader);
					try {
						Assert.assertTrue(emailHeaderText.contains(predefinedString));
						System.out.println("Email Header Contains: " + predefinedString + " String ");

					} catch (AssertionError e) {
						System.out.println("Email Header does not Contains: " + predefinedString + " String");
					}
					try {
						Assert.assertTrue(tableDataValidationd(driver, emailBody, predefinedString));
						System.out.println("Email Body Contains: " + predefinedString + " String ");

					} catch (AssertionError e) {
						System.out.println("Email Body does not Contains: " + predefinedString + " String");
					}

				}
				tearDown();
			}
		}
	}

}
